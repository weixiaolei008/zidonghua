<template>
  <div style="width: 100%; height: 100%">
    <router-view></router-view>
  </div>
</template>
<script>
  export default {
    name: "viewContent"
  }
</script>
<style scoped>
</style>
