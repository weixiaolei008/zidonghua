const state = {
  isCollapse: false, // 左侧菜单是否收缩
  menuChange: true, // 是否进入单个项目
  projectRow: null,
  porjectCode: null,
  porjectName: null,
  activeMenu: null, // 点击返回按钮是让菜单和页面保持一致
  activeName: null, // 一级面包屑名字
  activeName2: null // 二级面包屑名字
}

export default state
