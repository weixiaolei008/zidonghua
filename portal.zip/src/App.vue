<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>

  /*@import "./common/style/common.css";*/
  @import "./common/fonts/style.css";
  @import "./common/fontSize/iconfont.css";
</style>
